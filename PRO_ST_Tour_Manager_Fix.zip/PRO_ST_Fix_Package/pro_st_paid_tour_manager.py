import os
import re
import sqlite3
import discord
from discord.ext import commands
from discord.ui import View, Button, Select, Modal, TextInput

# ============================================================
# PRO ST PAID TOUR MANAGER
# Requirements: Python 3.10+ and discord.py 2.x
# Set DISCORD_BOT_TOKEN as an environment variable.
# ============================================================

TOKEN = os.getenv("DISCORD_BOT_TOKEN")
DB_FILE = "probot.db"

MANAGER_ROLE = "Tournament Manager"
MOD_ROLE = "Scrim Mod"
LOG_CHANNEL = "pst-pait-tour-logs"
REG_CHANNEL = "paid-tour-reg"
PANEL_TITLE = "PRO ST Paid Tour Manager"
RED = discord.Colour.red()

SCRIM_MAPS = "Bermuda, Purgatory, Kalahari"

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents)
views_loaded = False


# ============================================================
# EMBEDS / INTERACTION HELPERS
# ============================================================

def make_embed(title, description=None):
    return discord.Embed(title=title, description=description, colour=RED)


async def reply_embed(target, title, description, ephemeral=False):
    embed = make_embed(title, description)
    if isinstance(target, discord.Interaction):
        if target.response.is_done():
            await target.followup.send(embed=embed, ephemeral=ephemeral)
        else:
            await target.response.send_message(embed=embed, ephemeral=ephemeral)
    else:
        await target.reply(embed=embed)


def safe_text(value, fallback="Not set"):
    value = (value or "").strip()
    return value if value else fallback


def slugify(value):
    value = re.sub(r"[^a-zA-Z0-9-]", "-", (value or "").lower())
    value = re.sub(r"-+", "-", value).strip("-")
    return (value[:80] or "tour").strip("-")


def parse_maps(value):
    maps = [part.strip() for part in (value or "").replace("\n", ",").split(",")]
    return ", ".join(part for part in maps if part) or "Not set"


def format_tour(tour):
    tour_type = (tour["tour_type"] or "scrim").replace("_", " ").title()
    lines = [
        f"**Type:** {tour_type}",
        f"**Name:** {tour['name']}",
        f"**Mode:** {safe_text(tour['mode'])}",
        f"**Date & time:** {safe_text(tour['date_time'])}",
        f"**Entry fee:** {safe_text(tour['fee'])}",
        f"**Matches:** {tour['matches'] or 3}",
        f"**Maps:** {safe_text(tour['maps'])}",
    ]
    if (tour["tour_type"] or "").lower() == "champion_rush":
        lines.append(f"**Champion Rush unlock:** {safe_text(tour['unlock_points'])} points")
    lines.append(f"**Total slots:** {tour['total_slots']}")
    lines.append(f"**Tour ID:** `{tour['id']}`")
    return "\n".join(lines)


# ============================================================
# DATABASE + SAFE MIGRATIONS
# ============================================================

def db():
    conn = sqlite3.connect(DB_FILE, timeout=20)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def columns_for(conn, table):
    return {
        row["name"] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()
    }


def add_missing_columns(conn, table, columns):
    existing = columns_for(conn, table)
    for name, definition in columns.items():
        if name not in existing:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {definition}")


def init_db():
    with db() as conn:
        conn.execute("""
        CREATE TABLE IF NOT EXISTS tournaments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            mode TEXT,
            date_time TEXT,
            fee TEXT,
            total_slots INTEGER,
            guild_id INTEGER,
            role_id INTEGER,
            channel_id INTEGER,
            tour_type TEXT DEFAULT 'scrim',
            matches INTEGER DEFAULT 3,
            maps TEXT DEFAULT 'Bermuda, Purgatory, Kalahari',
            unlock_points TEXT
        )
        """)
        conn.execute("""
        CREATE TABLE IF NOT EXISTS registrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tournament_id INTEGER,
            slot_number INTEGER,
            discord_user_id INTEGER,
            team_name TEXT,
            p1_ign TEXT,
            p1_uid TEXT,
            p2_ign TEXT,
            p2_uid TEXT,
            status TEXT DEFAULT 'pending',
            created_at TEXT,
            transaction_id TEXT,
            screenshot_url TEXT,
            review_message_id INTEGER,
            review_channel_id INTEGER
        )
        """)
        conn.execute("""
        CREATE TABLE IF NOT EXISTS slots (
            tournament_id INTEGER,
            slot_number INTEGER,
            status TEXT DEFAULT 'available',
            team_name TEXT,
            PRIMARY KEY (tournament_id, slot_number)
        )
        """)
        conn.execute("""
        CREATE TABLE IF NOT EXISTS guild_settings (
            guild_id INTEGER PRIMARY KEY,
            registration_channel_id INTEGER,
            log_channel_id INTEGER,
            mod_role_id INTEGER,
            payment_method TEXT,
            payment_number TEXT
        )
        """)

        # Migrate databases created by earlier versions of the bot.
        add_missing_columns(conn, "tournaments", {
            "guild_id": "INTEGER",
            "role_id": "INTEGER",
            "channel_id": "INTEGER",
            "tour_type": "TEXT DEFAULT 'scrim'",
            "matches": "INTEGER DEFAULT 3",
            "maps": f"TEXT DEFAULT '{SCRIM_MAPS}'",
            "unlock_points": "TEXT",
        })
        add_missing_columns(conn, "registrations", {
            "p1_uid": "TEXT",
            "p2_uid": "TEXT",
            "created_at": "TEXT",
            "transaction_id": "TEXT",
            "screenshot_url": "TEXT",
            "review_message_id": "INTEGER",
            "review_channel_id": "INTEGER",
        })
        add_missing_columns(conn, "guild_settings", {
            "registration_channel_id": "INTEGER",
            "log_channel_id": "INTEGER",
            "mod_role_id": "INTEGER",
            "payment_method": "TEXT",
            "payment_number": "TEXT",
        })

        # Backfill defaults for existing tournament records.
        conn.execute("""
            UPDATE tournaments
            SET tour_type='scrim'
            WHERE tour_type IS NULL OR TRIM(tour_type)=''
        """)
        conn.execute("""
            UPDATE tournaments SET matches=3
            WHERE matches IS NULL OR matches < 1
        """)
        conn.execute("""
            UPDATE tournaments SET maps=?
            WHERE maps IS NULL OR TRIM(maps)=''
        """, (SCRIM_MAPS,))


def get_tournament(tournament_id):
    with db() as conn:
        return conn.execute(
            "SELECT * FROM tournaments WHERE id=?", (tournament_id,)
        ).fetchone()


def tournament_options(guild_id):
    with db() as conn:
        return conn.execute("""
            SELECT * FROM tournaments
            WHERE guild_id=?
            ORDER BY id DESC
        """, (guild_id,)).fetchall()


def get_settings(guild_id):
    if guild_id is None:
        return None
    with db() as conn:
        return conn.execute(
            "SELECT * FROM guild_settings WHERE guild_id=?", (guild_id,)
        ).fetchone()


def save_settings(guild_id, **values):
    allowed = {
        "registration_channel_id", "log_channel_id", "mod_role_id",
        "payment_method", "payment_number"
    }
    with db() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO guild_settings (guild_id) VALUES (?)",
            (guild_id,)
        )
        for key, value in values.items():
            if key in allowed:
                conn.execute(
                    f"UPDATE guild_settings SET {key}=? WHERE guild_id=?",
                    (value, guild_id)
                )


def is_manager(member):
    return isinstance(member, discord.Member) and (
        member.guild_permissions.administrator
        or any(role.name == MANAGER_ROLE for role in member.roles)
    )


def is_mod(member, guild_id):
    if not isinstance(member, discord.Member):
        return False
    if member.guild_permissions.administrator:
        return True
    settings = get_settings(guild_id)
    if settings and settings["mod_role_id"]:
        return any(role.id == settings["mod_role_id"] for role in member.roles)
    return any(role.name == MOD_ROLE for role in member.roles)


# ============================================================
# AUTOMATIC SERVER SETUP
# ============================================================

async def ensure_mod_setup(guild):
    settings = get_settings(guild.id)
    role = guild.get_role(settings["mod_role_id"]) if settings and settings["mod_role_id"] else None
    if role is None:
        role = discord.utils.get(guild.roles, name=MOD_ROLE)
    if role is None:
        role = await guild.create_role(
            name=MOD_ROLE, colour=discord.Colour.green(),
            reason="PRO ST payment verification role"
        )

    channel = guild.get_channel(settings["log_channel_id"]) if settings and settings["log_channel_id"] else None
    named_channel = discord.utils.get(guild.text_channels, name=LOG_CHANNEL)
    if named_channel:
        channel = named_channel
    elif channel is not None and channel.name != LOG_CHANNEL:
        try:
            await channel.edit(name=LOG_CHANNEL, reason="Rename PRO ST payment log channel")
        except discord.HTTPException:
            channel = None

    if channel is None:
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            role: discord.PermissionOverwrite(
                view_channel=True, send_messages=True, read_message_history=True,
                attach_files=True, embed_links=True
            ),
        }
        if guild.me:
            overwrites[guild.me] = discord.PermissionOverwrite(
                view_channel=True, send_messages=True, read_message_history=True,
                attach_files=True, embed_links=True, manage_channels=True
            )
        channel = await guild.create_text_channel(
            LOG_CHANNEL, overwrites=overwrites,
            reason="Private PRO ST payment verification log"
        )

    save_settings(guild.id, log_channel_id=channel.id, mod_role_id=role.id)
    return channel, role


async def ensure_registration_channel(guild):
    settings = get_settings(guild.id)
    channel = None

    # Always use the specifically requested public registration channel name.
    named_channel = discord.utils.get(guild.text_channels, name=REG_CHANNEL)
    if named_channel:
        channel = named_channel
    elif settings and settings["registration_channel_id"]:
        old_channel = guild.get_channel(settings["registration_channel_id"])
        if old_channel is not None:
            try:
                await old_channel.edit(name=REG_CHANNEL, reason="Rename PRO ST registration channel")
                channel = old_channel
            except discord.HTTPException:
                channel = None

    if channel is None:
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(
                view_channel=True, read_message_history=True, send_messages=True,
                embed_links=True, attach_files=True
            )
        }
        if guild.me:
            overwrites[guild.me] = discord.PermissionOverwrite(
                view_channel=True, read_message_history=True, send_messages=True,
                embed_links=True, manage_channels=True
            )
        channel = await guild.create_text_channel(
            REG_CHANNEL, overwrites=overwrites,
            reason="Public PRO ST paid tournament registration"
        )

    save_settings(guild.id, registration_channel_id=channel.id)
    return channel


async def post_tour_registration(guild, tour_id):
    tour = get_tournament(tour_id)
    if not tour:
        return
    channel = await ensure_registration_channel(guild)
    embed = make_embed(
        f"Registration Open — {tour['name']}",
        format_tour(tour) + "\n\n**To register:** Click Register, choose this tour, review its information, then click Register This Tour."
    )
    await channel.send(embed=embed, view=RegistrationView())


# ============================================================
# CREATE TOUR FLOW
# ============================================================

class TourTypeSelect(Select):
    def __init__(self):
        super().__init__(
            placeholder="Choose tournament type",
            min_values=1, max_values=1,
            options=[
                discord.SelectOption(label="Scrim", value="scrim", description="3 matches; Bermuda, Purgatory, Kalahari"),
                discord.SelectOption(label="Champion Rush", value="champion_rush", description="Set matches, maps and unlock points"),
                discord.SelectOption(label="Custom Tournament", value="custom", description="Set Solo/Duo/Squad, matches and maps"),
            ]
        )

    async def callback(self, interaction):
        if not is_manager(interaction.user):
            return await reply_embed(interaction, "Permission Denied", "এই action করার permission নেই.", ephemeral=True)
        await interaction.response.send_modal(CreateTourBaseModal(self.values[0]))


class TourTypePicker(View):
    def __init__(self):
        super().__init__(timeout=120)
        self.add_item(TourTypeSelect())


class CreateTourBaseModal(Modal):
    def __init__(self, tour_type):
        title = {
            "scrim": "Create Scrim Tour",
            "champion_rush": "Create Champion Rush",
            "custom": "Create Custom Tournament",
        }.get(tour_type, "Create Tour")
        super().__init__(title=title)
        self.tour_type = tour_type
        self.name_field = TextInput(label="Tour name", max_length=80, placeholder="PRO ST Paid Tour")
        self.date_field = TextInput(label="Date and time", max_length=80, placeholder="20 Oct, 8:00 PM")
        self.fee_field = TextInput(label="Entry fee", max_length=40, placeholder="50 BDT")
        self.slots_field = TextInput(label="Total slots", max_length=3, placeholder="12")
        for item in (self.name_field, self.date_field, self.fee_field, self.slots_field):
            self.add_item(item)

    async def on_submit(self, interaction):
        if not is_manager(interaction.user):
            return await reply_embed(interaction, "Permission Denied", "এই action করার permission নেই.", ephemeral=True)
        try:
            total_slots = int(self.slots_field.value.strip())
            if not 1 <= total_slots <= 500:
                raise ValueError
        except ValueError:
            return await reply_embed(interaction, "Invalid Slots", "Slot সংখ্যা 1 থেকে 500-এর মধ্যে হতে হবে.", ephemeral=True)

        await interaction.response.send_message(
            embed=make_embed("Continue Tour Setup", "Basic information saved for this setup. Click Continue to enter mode, matches, maps and any Champion Rush unlock points."),
            view=ContinueCreateTourView(
                self.tour_type, self.name_field.value.strip(),
                self.date_field.value.strip(), self.fee_field.value.strip(),
                total_slots
            ),
            ephemeral=True
        )


class ContinueCreateTourView(View):
    def __init__(self, tour_type, name, date_time, fee, total_slots):
        super().__init__(timeout=180)
        self.tour_type = tour_type
        self.tour_name = name
        self.date_time = date_time
        self.fee = fee
        self.total_slots = total_slots

    @discord.ui.button(label="Continue", style=discord.ButtonStyle.primary)
    async def continue_setup(self, interaction, button):
        if not is_manager(interaction.user):
            return await reply_embed(interaction, "Permission Denied", "এই action করার permission নেই.", ephemeral=True)
        await interaction.response.send_modal(CreateTourDetailsModal(
            self.tour_type, self.tour_name, self.date_time, self.fee, self.total_slots
        ))


class CreateTourDetailsModal(Modal):
    def __init__(self, tour_type, name, date_time, fee, total_slots):
        self.tour_type = tour_type
        self.tour_name = name
        self.date_time = date_time
        self.fee = fee
        self.total_slots = total_slots

        title = {
            "scrim": "Scrim Settings",
            "champion_rush": "Champion Rush Settings",
            "custom": "Custom Tour Settings",
        }.get(tour_type, "Tour Settings")
        super().__init__(title=title)

        self.mode_field = TextInput(
            label="Mode: Solo / Duo / Squad", max_length=10,
            default="Squad" if tour_type == "scrim" else None,
            placeholder="Squad"
        )
        self.matches_field = None
        self.maps_field = None
        self.unlock_field = None

        if tour_type == "scrim":
            self.matches_field = TextInput(label="Matches (default 3)", default="3", max_length=3)
            self.maps_field = TextInput(label="Maps (default B/P/K)", default=SCRIM_MAPS, max_length=200)
            self.add_item(self.mode_field)
            self.add_item(self.matches_field)
            self.add_item(self.maps_field)
        elif tour_type == "champion_rush":
            self.matches_field = TextInput(label="Number of matches", placeholder="6", max_length=3)
            self.maps_field = TextInput(label="Maps, comma separated", placeholder="Bermuda, Purgatory", max_length=200)
            self.unlock_field = TextInput(label="Champion Rush unlock points", placeholder="Point target", max_length=50)
            self.add_item(self.mode_field)
            self.add_item(self.matches_field)
            self.add_item(self.maps_field)
            self.add_item(self.unlock_field)
        else:
            self.matches_field = TextInput(label="Number of matches", placeholder="3", max_length=3)
            self.maps_field = TextInput(label="Maps, comma separated", placeholder="Bermuda, Purgatory", max_length=200)
            self.add_item(self.mode_field)
            self.add_item(self.matches_field)
            self.add_item(self.maps_field)

    async def on_submit(self, interaction):
        if not is_manager(interaction.user):
            return await reply_embed(interaction, "Permission Denied", "এই action করার permission নেই.", ephemeral=True)

        mode = self.mode_field.value.strip().title()
        if mode not in ("Solo", "Duo", "Squad"):
            return await reply_embed(interaction, "Invalid Mode", "Mode অবশ্যই Solo, Duo অথবা Squad হতে হবে.", ephemeral=True)

        try:
            matches = int(self.matches_field.value.strip())
            if not 1 <= matches <= 30:
                raise ValueError
        except (ValueError, AttributeError):
            return await reply_embed(interaction, "Invalid Matches", "Match সংখ্যা 1 থেকে 30-এর মধ্যে হতে হবে.", ephemeral=True)

        maps = parse_maps(self.maps_field.value if self.maps_field else SCRIM_MAPS)
        if self.tour_type == "scrim" and not maps:
            maps = SCRIM_MAPS
        unlock = self.unlock_field.value.strip() if self.unlock_field else None
        if self.tour_type == "champion_rush" and not unlock:
            return await reply_embed(interaction, "Unlock Points Required", "Champion Rush unlock point লিখতে হবে.", ephemeral=True)

        guild = interaction.guild
        if not guild:
            return await reply_embed(interaction, "Server Required", "Server-এর মধ্যে ব্যবহার করো.", ephemeral=True)

        role = None
        channel = None
        tour_id = None
        try:
            role = await guild.create_role(
                name=f"{self.tour_name[:80]} Players",
                reason="PRO ST tournament player role"
            )
            overwrites = {
                guild.default_role: discord.PermissionOverwrite(view_channel=False),
                role: discord.PermissionOverwrite(
                    view_channel=True, send_messages=True, read_message_history=True
                ),
            }
            if guild.me:
                overwrites[guild.me] = discord.PermissionOverwrite(
                    view_channel=True, send_messages=True, read_message_history=True,
                    manage_channels=True, embed_links=True, attach_files=True
                )
            channel = await guild.create_text_channel(
                f"tour-{slugify(self.tour_name)}"[:100],
                overwrites=overwrites,
                reason="PRO ST private tournament channel"
            )

            with db() as conn:
                cursor = conn.execute("""
                    INSERT INTO tournaments
                    (name, mode, date_time, fee, total_slots, guild_id, role_id,
                     channel_id, tour_type, matches, maps, unlock_points)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    self.tour_name, mode, self.date_time, self.fee,
                    self.total_slots, guild.id, role.id, channel.id,
                    self.tour_type, matches, maps, unlock
                ))
                tour_id = cursor.lastrowid
                conn.executemany("""
                    INSERT INTO slots (tournament_id, slot_number, status, team_name)
                    VALUES (?, ?, 'available', NULL)
                """, [(tour_id, n) for n in range(1, self.total_slots + 1)])

            reg_channel = await ensure_registration_channel(guild)
            try:
                await post_tour_registration(guild, tour_id)
                announcement = f"\n**Registration post:** {reg_channel.mention}"
            except Exception as post_error:
                print("Registration announcement error:", repr(post_error))
                announcement = "\n**Warning:** Tour তৈরি হয়েছে, কিন্তু registration post পাঠানো যায়নি। Bot-এর channel permissions পরীক্ষা করো."

            tour = get_tournament(tour_id)
            embed = make_embed("Tour Created Successfully", format_tour(tour))
            embed.add_field(name="Private channel", value=channel.mention, inline=True)
            embed.add_field(name="Player role", value=role.mention, inline=True)
            await interaction.response.send_message(
                embed=embed, ephemeral=True
            )
            if announcement.startswith("\n**Warning"):
                await interaction.followup.send(announcement, ephemeral=True)

        except Exception as error:
            print("Create tour error:", repr(error))
            if tour_id:
                with db() as conn:
                    conn.execute("DELETE FROM slots WHERE tournament_id=?", (tour_id,))
                    conn.execute("DELETE FROM tournaments WHERE id=?", (tour_id,))
            for resource in (channel, role):
                if resource:
                    try:
                        await resource.delete(reason="Tour creation failed")
                    except discord.HTTPException:
                        pass
            await reply_embed(interaction, "Create Failed", "Tour তৈরি করা যায়নি। Bot-এর Manage Roles, Manage Channels ও channel permissions পরীক্ষা করো.", ephemeral=True)


# ============================================================
# EDIT TOUR
# ============================================================

class EditTourBaseModal(Modal):
    def __init__(self, tour_id):
        super().__init__(title="Edit Tour Details")
        self.tour_id = tour_id
        tour = get_tournament(tour_id)
        self.name_field = TextInput(label="Tour name", default=tour["name"][:80], max_length=80)
        self.date_field = TextInput(label="Date and time", default=(tour["date_time"] or "")[:80], max_length=80)
        self.fee_field = TextInput(label="Entry fee", default=(tour["fee"] or "")[:40], max_length=40)
        self.slots_field = TextInput(label="Total slots", default=str(tour["total_slots"]), max_length=3)
        for item in (self.name_field, self.date_field, self.fee_field, self.slots_field):
            self.add_item(item)

    async def on_submit(self, interaction):
        tour = get_tournament(self.tour_id)
        if not tour or tour["guild_id"] != interaction.guild_id:
            return await reply_embed(interaction, "Tour Not Found", "Tour পাওয়া যায়নি.", ephemeral=True)
        try:
            total_slots = int(self.slots_field.value.strip())
            if not 1 <= total_slots <= 500:
                raise ValueError
        except ValueError:
            return await reply_embed(interaction, "Invalid Slots", "Slot সংখ্যা 1 থেকে 500-এর মধ্যে হতে হবে.", ephemeral=True)

        with db() as conn:
            highest_used = conn.execute("""
                SELECT COALESCE(MAX(slot_number), 0) AS n FROM registrations
                WHERE tournament_id=? AND status NOT IN ('rejected', 'cancelled')
            """, (self.tour_id,)).fetchone()["n"]
            if total_slots < highest_used:
                return await reply_embed(interaction, "Cannot Reduce Slots", f"Slot {highest_used} পর্যন্ত registration আছে। Total slots কমপক্ষে {highest_used} হতে হবে.", ephemeral=True)
            conn.execute("""
                UPDATE tournaments SET name=?, date_time=?, fee=?, total_slots=?
                WHERE id=?
            """, (self.name_field.value.strip(), self.date_field.value.strip(),
                  self.fee_field.value.strip(), total_slots, self.tour_id))
            for slot_no in range(1, total_slots + 1):
                conn.execute("""
                    INSERT OR IGNORE INTO slots (tournament_id, slot_number, status, team_name)
                    VALUES (?, ?, 'available', NULL)
                """, (self.tour_id, slot_no))
            conn.execute("""
                DELETE FROM slots WHERE tournament_id=? AND slot_number>?
                AND status='available'
            """, (self.tour_id, total_slots))

        guild = interaction.guild
        if guild:
            role = guild.get_role(tour["role_id"]) if tour["role_id"] else None
            channel = guild.get_channel(tour["channel_id"]) if tour["channel_id"] else None
            if role:
                try:
                    await role.edit(name=f"{self.name_field.value.strip()[:80]} Players")
                except discord.HTTPException as error:
                    print("Role rename error:", repr(error))
            if channel:
                try:
                    await channel.edit(name=f"tour-{slugify(self.name_field.value)}"[:100])
                except discord.HTTPException as error:
                    print("Private channel rename error:", repr(error))

        await interaction.response.send_message(
            embed=make_embed("Continue Editing Tour", "Basic information updated. Click Continue to edit mode, matches, maps and Champion Rush unlock points."),
            view=ContinueEditTourView(self.tour_id), ephemeral=True
        )


class ContinueEditTourView(View):
    def __init__(self, tour_id):
        super().__init__(timeout=180)
        self.tour_id = tour_id

    @discord.ui.button(label="Continue", style=discord.ButtonStyle.primary)
    async def continue_edit(self, interaction, button):
        if not is_manager(interaction.user):
            return await reply_embed(interaction, "Permission Denied", "এই action করার permission নেই.", ephemeral=True)
        await interaction.response.send_modal(EditTourDetailsModal(self.tour_id))


class EditTourDetailsModal(Modal):
    def __init__(self, tour_id):
        self.tour_id = tour_id
        tour = get_tournament(tour_id)
        self.tour_type = tour["tour_type"] or "scrim"
        super().__init__(title="Edit Tour Settings")
        self.mode_field = TextInput(label="Mode: Solo / Duo / Squad", default=(tour["mode"] or "Squad")[:10], max_length=10)
        self.matches_field = TextInput(label="Number of matches", default=str(tour["matches"] or 3), max_length=3)
        self.maps_field = TextInput(label="Maps, comma separated", default=(tour["maps"] or SCRIM_MAPS)[:200], max_length=200)
        self.unlock_field = None
        self.add_item(self.mode_field)
        self.add_item(self.matches_field)
        self.add_item(self.maps_field)
        if self.tour_type == "champion_rush":
            self.unlock_field = TextInput(label="Champion Rush unlock points", default=(tour["unlock_points"] or "")[:50], max_length=50)
            self.add_item(self.unlock_field)

    async def on_submit(self, interaction):
        tour = get_tournament(self.tour_id)
        if not tour or tour["guild_id"] != interaction.guild_id:
            return await reply_embed(interaction, "Tour Not Found", "Tour পাওয়া যায়নি.", ephemeral=True)
        mode = self.mode_field.value.strip().title()
        if mode not in ("Solo", "Duo", "Squad"):
            return await reply_embed(interaction, "Invalid Mode", "Mode অবশ্যই Solo, Duo অথবা Squad হতে হবে.", ephemeral=True)
        try:
            matches = int(self.matches_field.value.strip())
            if not 1 <= matches <= 30:
                raise ValueError
        except ValueError:
            return await reply_embed(interaction, "Invalid Matches", "Match সংখ্যা 1 থেকে 30-এর মধ্যে হতে হবে.", ephemeral=True)
        maps = parse_maps(self.maps_field.value)
        unlock = self.unlock_field.value.strip() if self.unlock_field else tour["unlock_points"]
        if self.tour_type == "champion_rush" and not unlock:
            return await reply_embed(interaction, "Unlock Points Required", "Champion Rush unlock point লিখতে হবে.", ephemeral=True)

        with db() as conn:
            conn.execute("""
                UPDATE tournaments SET mode=?, matches=?, maps=?, unlock_points=?
                WHERE id=?
            """, (mode, matches, maps, unlock, self.tour_id))
        updated = get_tournament(self.tour_id)
        await reply_embed(interaction, "Tour Updated", format_tour(updated), ephemeral=True)


# ============================================================
# DELETE TOUR
# ============================================================

class DeleteTourView(View):
    def __init__(self, tour_id):
        super().__init__(timeout=120)
        self.tour_id = tour_id

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction, button):
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(
            embed=make_embed("Cancelled", "Tour delete করা হয়নি."), view=self
        )

    @discord.ui.button(label="Confirm Delete", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction, button):
        if not is_manager(interaction.user):
            return await reply_embed(interaction, "Permission Denied", "এই action করার permission নেই.", ephemeral=True)
        tour = get_tournament(self.tour_id)
        if not tour or tour["guild_id"] != interaction.guild_id:
            return await reply_embed(interaction, "Tour Not Found", "Tour পাওয়া যায়নি.", ephemeral=True)

        guild = interaction.guild
        try:
            if guild and tour["channel_id"]:
                channel = guild.get_channel(tour["channel_id"])
                if channel:
                    await channel.delete(reason="Tour deleted by manager")
            if guild and tour["role_id"]:
                role = guild.get_role(tour["role_id"])
                if role:
                    await role.delete(reason="Tour deleted by manager")

            with db() as conn:
                conn.execute("DELETE FROM registrations WHERE tournament_id=?", (self.tour_id,))
                conn.execute("DELETE FROM slots WHERE tournament_id=?", (self.tour_id,))
                conn.execute("DELETE FROM tournaments WHERE id=?", (self.tour_id,))
            for item in self.children:
                item.disabled = True
            await interaction.response.edit_message(
                embed=make_embed("Tour Deleted", "Tour, registrations এবং slot records delete হয়েছে. পুরোনো registration announcement channel-এ থাকলে সেটি manually delete করতে হবে."),
                view=self
            )
        except Exception as error:
            print("Delete tour error:", repr(error))
            await reply_embed(interaction, "Delete Incomplete", "Discord channel/role delete করা যায়নি। Permissions পরীক্ষা করো; database record নিরাপদ রাখতে deletion থামানো হয়েছে.", ephemeral=True)


# ============================================================
# PAYMENT SETTINGS
# ============================================================

class PaymentModal(Modal, title="Set Payment Details"):
    method = TextInput(label="Payment method", placeholder="bKash or Nagad", max_length=20)
    number = TextInput(label="Payment number", placeholder="01XXXXXXXXX", max_length=30)

    async def on_submit(self, interaction):
        method = self.method.value.strip().lower()
        if method not in ("bkash", "nagad"):
            return await reply_embed(interaction, "Invalid Method", "bKash অথবা Nagad লিখো.", ephemeral=True)
        number = self.number.value.strip()
        if not number:
            return await reply_embed(interaction, "Invalid Number", "Payment number খালি রাখা যাবে না.", ephemeral=True)
        method_name = "bKash" if method == "bkash" else "Nagad"
        save_settings(interaction.guild_id, payment_method=method_name, payment_number=number)
        await reply_embed(interaction, "Payment Saved", f"**Method:** {method_name}\n**Number:** `{number}`", ephemeral=True)


# ============================================================
# REGISTRATION: CHOOSE TOUR -> TOUR INFO -> REGISTER
# ============================================================

class RegisterTourSelect(Select):
    def __init__(self, guild_id):
        tours = tournament_options(guild_id)
        options = [
            discord.SelectOption(
                label=row["name"][:100],
                description=f"{(row['tour_type'] or 'scrim').replace('_', ' ').title()} | Fee: {row['fee'] or 'Not set'}",
                value=str(row["id"])
            )
            for row in tours[:25]
        ]
        super().__init__(placeholder="Choose a current tournament", min_values=1, max_values=1, options=options)

    async def callback(self, interaction):
        tour_id = int(self.values[0])
        tour = get_tournament(tour_id)
        if not tour or tour["guild_id"] != interaction.guild_id:
            return await reply_embed(interaction, "Tour Not Found", "এই tour আর available নেই.", ephemeral=True)
        await interaction.response.send_message(
            embed=make_embed(f"Tour Information — {tour['name']}", format_tour(tour)),
            view=RegisterThisTourView(tour_id),
            ephemeral=True
        )


class RegisterTourPicker(View):
    def __init__(self, guild_id):
        super().__init__(timeout=120)
        if tournament_options(guild_id):
            self.add_item(RegisterTourSelect(guild_id))


class RegisterThisTourView(View):
    def __init__(self, tour_id):
        super().__init__(timeout=180)
        self.tour_id = tour_id

    @discord.ui.button(label="Register This Tour", style=discord.ButtonStyle.success)
    async def register_this(self, interaction, button):
        tour = get_tournament(self.tour_id)
        if not tour or tour["guild_id"] != interaction.guild_id:
            return await reply_embed(interaction, "Tour Not Found", "এই tour আর available নেই.", ephemeral=True)
        settings = get_settings(interaction.guild_id)
        if not settings or not settings["payment_number"] or not settings["payment_method"]:
            return await reply_embed(interaction, "Payment Not Configured", "Admin এখনো bKash/Nagad payment details set করেনি.", ephemeral=True)
        await interaction.response.send_modal(TeamInfoModal(self.tour_id))


class RegistrationView(View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Register", style=discord.ButtonStyle.success, custom_id="pro_st_register")
    async def register(self, interaction, button):
        if not interaction.guild_id:
            return await reply_embed(interaction, "Server Required", "Server-এর registration channel থেকে ব্যবহার করো.", ephemeral=True)
        tours = tournament_options(interaction.guild_id)
        if not tours:
            return await reply_embed(interaction, "No Current Tours", "এখন কোনো tournament available নেই.", ephemeral=True)
        await interaction.response.send_message(
            embed=make_embed("Choose a Tournament", "তালিকা থেকে tour select করো। এরপর tour-এর সব তথ্য দেখে Register This Tour-এ click করো."),
            view=RegisterTourPicker(interaction.guild_id),
            ephemeral=True
        )


class TeamInfoModal(Modal, title="Team Information"):
    team = TextInput(label="Team name", max_length=80)
    p1_ign = TextInput(label="Player 1 IGN", max_length=50)
    p2_ign = TextInput(label="Player 2 IGN", max_length=50)

    def __init__(self, tour_id):
        super().__init__()
        self.tour_id = tour_id

    async def on_submit(self, interaction):
        tour = get_tournament(self.tour_id)
        if not tour or tour["guild_id"] != interaction.guild_id:
            return await reply_embed(interaction, "Tour Not Found", "Tour পাওয়া যায়নি.", ephemeral=True)
        settings = get_settings(interaction.guild_id)
        if not settings or not settings["payment_number"] or not settings["payment_method"]:
            return await reply_embed(interaction, "Payment Not Configured", "Admin payment details set করেনি.", ephemeral=True)

        registration_id = None
        slot_number = None
        # Reserve a slot and create the registration atomically only after all team info is submitted.
        try:
            with db() as conn:
                conn.execute("BEGIN IMMEDIATE")
                existing = conn.execute("""
                    SELECT id FROM registrations
                    WHERE tournament_id=? AND discord_user_id=?
                    AND status IN ('collecting_info', 'awaiting_screenshot', 'processing_screenshot', 'pending', 'accepted')
                """, (self.tour_id, interaction.user.id)).fetchone()
                if existing:
                    conn.rollback()
                    return await reply_embed(interaction, "Already Registered", "এই tour-এ তোমার registration আগে থেকেই আছে.", ephemeral=True)

                slot = conn.execute("""
                    SELECT slot_number FROM slots
                    WHERE tournament_id=? AND status='available'
                    ORDER BY slot_number LIMIT 1
                """, (self.tour_id,)).fetchone()
                if not slot:
                    conn.rollback()
                    return await reply_embed(interaction, "Tour Full", "এই tour-এর সব slot পূর্ণ.", ephemeral=True)
                slot_number = slot["slot_number"]
                cursor = conn.execute("""
                    INSERT INTO registrations
                    (tournament_id, slot_number, discord_user_id, team_name,
                     p1_ign, p1_uid, p2_ign, p2_uid, status, created_at)
                    VALUES (?, ?, ?, ?, ?, '', ?, '', 'awaiting_screenshot', datetime('now'))
                """, (
                    self.tour_id, slot_number, interaction.user.id,
                    self.team.value.strip(), self.p1_ign.value.strip(), self.p2_ign.value.strip()
                ))
                registration_id = cursor.lastrowid
                updated = conn.execute("""
                    UPDATE slots SET status='reserved', team_name=?
                    WHERE tournament_id=? AND slot_number=? AND status='available'
                """, (self.team.value.strip(), self.tour_id, slot_number))
                if updated.rowcount != 1:
                    conn.rollback()
                    return await reply_embed(interaction, "Slot Conflict", "Slot নেওয়া যায়নি। আবার register করো.", ephemeral=True)
                conn.commit()
        except sqlite3.Error as error:
            print("Registration database error:", repr(error))
            return await reply_embed(interaction, "Registration Failed", "Database error হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করো.", ephemeral=True)

        payment_embed = make_embed(
            "Payment Instructions",
            f"**Tournament:** {tour['name']}\n"
            f"**Team:** {self.team.value.strip()}\n"
            f"**Reserved slot:** {slot_number}\n"
            f"**Entry fee:** {tour['fee'] or 'Not specified'}\n"
            f"**Payment method:** {settings['payment_method']}\n"
            f"**Payment number:** `{settings['payment_number']}`\n\n"
            "Payment করার পর এই DM-এ payment screenshot image হিসেবে পাঠাও।\n"
            "Moderator screenshot verify করার পর registration confirm হবে."
        )
        try:
            await interaction.user.send(embed=payment_embed)
        except discord.Forbidden:
            with db() as conn:
                conn.execute("DELETE FROM registrations WHERE id=?", (registration_id,))
                conn.execute("""
                    UPDATE slots SET status='available', team_name=NULL
                    WHERE tournament_id=? AND slot_number=? AND status='reserved'
                """, (self.tour_id, slot_number))
            return await reply_embed(interaction, "DM Disabled", "তোমার DM বন্ধ আছে। Server member-দের DM allow করে আবার register করো.", ephemeral=True)

        await reply_embed(interaction, "Team Information Saved", "Payment instructions তোমার DM-এ পাঠানো হয়েছে। Payment করার পর screenshot পাঠাও.", ephemeral=True)


# ============================================================
# SLOT LIST
# ============================================================

class SlotListView(View):
    def __init__(self, tour_name, entries, page=0):
        super().__init__(timeout=180)
        self.tour_name = tour_name
        self.entries = entries
        self.page = page
        self.page_size = 10
        self.previous_button = Button(label="Previous", style=discord.ButtonStyle.secondary)
        self.next_button = Button(label="Next", style=discord.ButtonStyle.secondary)
        self.previous_button.callback = self.previous
        self.next_button.callback = self.next_page
        self.add_item(self.previous_button)
        self.add_item(self.next_button)
        self.refresh_buttons()

    def refresh_buttons(self):
        max_page = max(0, (len(self.entries) - 1) // self.page_size)
        self.previous_button.disabled = self.page <= 0
        self.next_button.disabled = self.page >= max_page

    def make_page_embed(self):
        start = self.page * self.page_size
        chunk = self.entries[start:start + self.page_size]
        description = "\n".join(chunk) if chunk else "এই tournament-এ এখনো কোনো team register করেনি."
        embed = make_embed(f"Slot List — {self.tour_name}", description)
        embed.set_footer(text=f"Page {self.page + 1} / {max(1, (len(self.entries) + self.page_size - 1) // self.page_size)}")
        return embed

    async def previous(self, interaction):
        self.page = max(0, self.page - 1)
        self.refresh_buttons()
        await interaction.response.edit_message(embed=self.make_page_embed(), view=self)

    async def next_page(self, interaction):
        max_page = max(0, (len(self.entries) - 1) // self.page_size)
        self.page = min(max_page, self.page + 1)
        self.refresh_buttons()
        await interaction.response.edit_message(embed=self.make_page_embed(), view=self)


class SlotTourSelect(Select):
    def __init__(self, guild_id):
        tours = tournament_options(guild_id)
        options = [
            discord.SelectOption(
                label=row["name"][:100],
                description=f"{(row['tour_type'] or 'scrim').replace('_', ' ').title()} | ID {row['id']}",
                value=str(row["id"])
            ) for row in tours[:25]
        ]
        super().__init__(placeholder="Choose a tournament to view its slot list", min_values=1, max_values=1, options=options)

    async def callback(self, interaction):
        tour_id = int(self.values[0])
        tour = get_tournament(tour_id)
        if not tour or tour["guild_id"] != interaction.guild_id:
            return await reply_embed(interaction, "Tour Not Found", "Tour পাওয়া যায়নি.", ephemeral=True)
        with db() as conn:
            rows = conn.execute("""
                SELECT * FROM registrations
                WHERE tournament_id=? AND status NOT IN ('rejected', 'cancelled')
                ORDER BY slot_number
            """, (tour_id,)).fetchall()
        entries = []
        for row in rows:
            entries.append(
                f"**Slot {row['slot_number']:02}** — **{row['team_name'] or 'Team not set'}**\n"
                f"Player 1: {row['p1_ign'] or '—'} | Player 2: {row['p2_ign'] or '—'}\n"
                f"Status: `{row['status']}`"
            )
        view = SlotListView(tour["name"], entries)
        await interaction.response.send_message(embed=view.make_page_embed(), view=view, ephemeral=True)


class SlotTourPicker(View):
    def __init__(self, guild_id):
        super().__init__(timeout=120)
        if tournament_options(guild_id):
            self.add_item(SlotTourSelect(guild_id))


# ============================================================
# PAYMENT SCREENSHOT IN DM + MOD REVIEW
# ============================================================

class ReviewView(View):
    def __init__(self, registration_id):
        super().__init__(timeout=None)
        self.registration_id = registration_id
        accept = Button(label="Accept", style=discord.ButtonStyle.success, custom_id=f"review_accept:{registration_id}")
        reject = Button(label="Reject", style=discord.ButtonStyle.danger, custom_id=f"review_reject:{registration_id}")
        accept.callback = self.accept
        reject.callback = self.reject
        self.add_item(accept)
        self.add_item(reject)

    async def decide(self, interaction, accepted):
        with db() as conn:
            row = conn.execute("""
                SELECT r.*, t.name AS tour_name, t.guild_id, t.role_id
                FROM registrations r JOIN tournaments t ON t.id=r.tournament_id
                WHERE r.id=?
            """, (self.registration_id,)).fetchone()
        if not row:
            return await reply_embed(interaction, "Not Found", "Registration পাওয়া যায়নি.", ephemeral=True)
        if not is_mod(interaction.user, row["guild_id"]):
            return await reply_embed(interaction, "Permission Denied", "শুধু Scrim Mod বা admin Accept/Reject করতে পারবে.", ephemeral=True)
        if not interaction.guild or interaction.guild.id != row["guild_id"]:
            return await reply_embed(interaction, "Wrong Server", "সঠিক server থেকে action করো.", ephemeral=True)

        new_status = "accepted" if accepted else "rejected"
        with db() as conn:
            conn.execute("BEGIN IMMEDIATE")
            cursor = conn.execute("""
                UPDATE registrations SET status=?
                WHERE id=? AND status='pending'
            """, (new_status, self.registration_id))
            if cursor.rowcount != 1:
                conn.rollback()
                return await reply_embed(interaction, "Already Reviewed", "অন্য moderator ইতিমধ্যে decision নিয়েছে.", ephemeral=True)
            if accepted:
                conn.execute("""
                    UPDATE slots SET status='booked', team_name=?
                    WHERE tournament_id=? AND slot_number=?
                """, (row["team_name"], row["tournament_id"], row["slot_number"]))
            else:
                conn.execute("""
                    UPDATE slots SET status='available', team_name=NULL
                    WHERE tournament_id=? AND slot_number=?
                """, (row["tournament_id"], row["slot_number"]))
            conn.commit()

        if accepted and row["role_id"]:
            member = interaction.guild.get_member(row["discord_user_id"])
            role = interaction.guild.get_role(row["role_id"])
            if member and role:
                try:
                    await member.add_roles(role, reason="PRO ST tour registration accepted")
                except discord.HTTPException as error:
                    print("Assign player role error:", repr(error))

        for item in self.children:
            item.disabled = True
        decision = "ACCEPTED" if accepted else "REJECTED"
        try:
            await interaction.message.edit(content=f"**{decision}** by {interaction.user.mention}", view=self)
        except discord.HTTPException:
            pass

        try:
            user = await bot.fetch_user(row["discord_user_id"])
            await user.send(embed=make_embed(
                f"Registration {decision}",
                f"**Tournament:** {row['tour_name']}\n**Team:** {row['team_name']}\n"
                f"**Slot:** {row['slot_number']}\n**Decision:** {decision}"
            ))
        except discord.HTTPException:
            pass
        await reply_embed(interaction, f"Registration {decision}", f"{row['team_name']} — {decision}.", ephemeral=True)

    async def accept(self, interaction):
        await self.decide(interaction, True)

    async def reject(self, interaction):
        await self.decide(interaction, False)


async def handle_screenshot(message):
    if message.author.bot or message.guild is not None:
        return
    with db() as conn:
        row = conn.execute("""
            SELECT r.*, t.name AS tour_name, t.guild_id
            FROM registrations r JOIN tournaments t ON t.id=r.tournament_id
            WHERE r.discord_user_id=? AND r.status='awaiting_screenshot'
            ORDER BY r.id DESC LIMIT 1
        """, (message.author.id,)).fetchone()

    if not row:
        if message.attachments:
            await message.channel.send(embed=make_embed("No Pending Registration", "তোমার কোনো registration screenshot-এর জন্য অপেক্ষা করছে না."))
        return
    if not message.attachments:
        await message.channel.send(embed=make_embed("Payment Screenshot Needed", "Payment screenshot image হিসেবে পাঠাও."))
        return
    attachment = next((item for item in message.attachments if item.content_type and item.content_type.startswith("image/")), None)
    if not attachment:
        await message.channel.send(embed=make_embed("Invalid Screenshot", "PNG, JPG বা অন্য image format-এ screenshot পাঠাও."))
        return

    # Claim this screenshot attempt so two simultaneous DMs cannot create duplicate reviews.
    with db() as conn:
        cursor = conn.execute("""
            UPDATE registrations SET status='processing_screenshot'
            WHERE id=? AND status='awaiting_screenshot'
        """, (row["id"],))
        if cursor.rowcount != 1:
            return await message.channel.send(embed=make_embed("Screenshot Already Processing", "তোমার screenshot ইতিমধ্যে process হচ্ছে."))
    guild = bot.get_guild(row["guild_id"])
    settings = get_settings(row["guild_id"]) if guild else None
    log_channel = guild.get_channel(settings["log_channel_id"]) if guild and settings and settings["log_channel_id"] else None
    if not log_channel:
        with db() as conn:
            conn.execute("UPDATE registrations SET status='awaiting_screenshot' WHERE id=? AND status='processing_screenshot'", (row["id"],))
        return await message.channel.send(embed=make_embed("Review Channel Missing", "Private review channel পাওয়া যায়নি. Server admin-কে জানাও."))

    embed = make_embed("New Payment Verification", "Scrim Mod: payment details এবং screenshot যাচাই করে সিদ্ধান্ত নাও.")
    embed.add_field(name="Tournament", value=row["tour_name"], inline=False)
    embed.add_field(name="Registration ID", value=str(row["id"]), inline=True)
    embed.add_field(name="Slot", value=str(row["slot_number"]), inline=True)
    embed.add_field(name="Team", value=row["team_name"] or "—", inline=False)
    embed.add_field(name="Player 1", value=f"IGN: {row['p1_ign'] or '—'}", inline=True)
    embed.add_field(name="Player 2", value=f"IGN: {row['p2_ign'] or '—'}", inline=True)
    embed.add_field(name="Registered by", value=f"<@{row['discord_user_id']}>", inline=False)
    embed.set_footer(text="Verify the payment screenshot before accepting.")

    try:
        file = await attachment.to_file()
        mention = f"<@&{settings['mod_role_id']}>" if settings and settings["mod_role_id"] else "Scrim Mod"
        review_message = await log_channel.send(
            content=f"{mention} — new payment screenshot needs verification.",
            embed=embed, file=file, view=ReviewView(row["id"]),
            allowed_mentions=discord.AllowedMentions(roles=True, users=False, everyone=False)
        )
        with db() as conn:
            cursor = conn.execute("""
                UPDATE registrations SET status='pending', screenshot_url=?,
                    review_message_id=?, review_channel_id=?
                WHERE id=? AND status='processing_screenshot'
            """, (attachment.url, review_message.id, log_channel.id, row["id"]))
            if cursor.rowcount != 1:
                print("Warning: review message posted but registration status changed.")
        await message.channel.send(embed=make_embed("Screenshot Submitted", "তোমার screenshot Scrim Mod-দের কাছে পাঠানো হয়েছে. Verification-এর জন্য অপেক্ষা করো."))
    except Exception as error:
        print("Screenshot error:", repr(error))
        with db() as conn:
            conn.execute("UPDATE registrations SET status='awaiting_screenshot' WHERE id=? AND status='processing_screenshot'", (row["id"],))
        await message.channel.send(embed=make_embed("Upload Failed", "Screenshot পাঠানো যায়নি. আবার চেষ্টা করো."))


# ============================================================
# TOUR PICKER: EDIT / DELETE
# ============================================================

class TourSelect(Select):
    def __init__(self, action, guild_id):
        self.action = action
        tours = tournament_options(guild_id)
        options = [
            discord.SelectOption(
                label=row["name"][:100],
                description=f"{(row['tour_type'] or 'scrim').replace('_', ' ').title()} | ID: {row['id']}",
                value=str(row["id"])
            ) for row in tours[:25]
        ]
        super().__init__(placeholder="Select a tournament", min_values=1, max_values=1, options=options)

    async def callback(self, interaction):
        if not is_manager(interaction.user):
            return await reply_embed(interaction, "Permission Denied", "এই action করার permission নেই.", ephemeral=True)
        tour_id = int(self.values[0])
        tour = get_tournament(tour_id)
        if not tour or tour["guild_id"] != interaction.guild_id:
            return await reply_embed(interaction, "Tour Not Found", "Tour পাওয়া যায়নি.", ephemeral=True)
        if self.action == "edit":
            await interaction.response.send_modal(EditTourBaseModal(tour_id))
        elif self.action == "delete":
            await interaction.response.send_message(
                embed=make_embed("Confirm Delete", f"**{tour['name']}** এবং এর linked private channel, role, registrations ও slots delete হবে. নিশ্চিত?"),
                view=DeleteTourView(tour_id), ephemeral=True
            )


class TourPicker(View):
    def __init__(self, action, guild_id):
        super().__init__(timeout=120)
        if tournament_options(guild_id):
            self.add_item(TourSelect(action, guild_id))


# ============================================================
# ADMIN PANEL
# ============================================================

class Panel(View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Create Tour", style=discord.ButtonStyle.success, custom_id="panel_create_tour")
    async def create(self, interaction, button):
        if not is_manager(interaction.user):
            return await reply_embed(interaction, "Permission Denied", "এই action করার permission নেই.", ephemeral=True)
        await interaction.response.send_message(
            embed=make_embed("Create Tour", "Scrim, Champion Rush অথবা Custom Tournament বেছে নাও."),
            view=TourTypePicker(), ephemeral=True
        )

    @discord.ui.button(label="Edit Tour", style=discord.ButtonStyle.secondary, custom_id="panel_edit_tour")
    async def edit(self, interaction, button):
        if not is_manager(interaction.user):
            return await reply_embed(interaction, "Permission Denied", "এই action করার permission নেই.", ephemeral=True)
        if not tournament_options(interaction.guild_id):
            return await reply_embed(interaction, "No Tours", "এই server-এ কোনো tournament নেই.", ephemeral=True)
        await interaction.response.send_message(
            embed=make_embed("Edit Tour", "যে tournament edit করবে সেটি select করো."),
            view=TourPicker("edit", interaction.guild_id), ephemeral=True
        )

    @discord.ui.button(label="Delete Tour", style=discord.ButtonStyle.danger, custom_id="panel_delete_tour")
    async def delete(self, interaction, button):
        if not is_manager(interaction.user):
            return await reply_embed(interaction, "Permission Denied", "এই action করার permission নেই.", ephemeral=True)
        if not tournament_options(interaction.guild_id):
            return await reply_embed(interaction, "No Tours", "এই server-এ কোনো tournament নেই.", ephemeral=True)
        await interaction.response.send_message(
            embed=make_embed("Delete Tour", "যে tournament delete করবে সেটি select করো."),
            view=TourPicker("delete", interaction.guild_id), ephemeral=True
        )

    @discord.ui.button(label="Slot List", style=discord.ButtonStyle.primary, custom_id="panel_slot_list")
    async def slots(self, interaction, button):
        if not is_manager(interaction.user):
            return await reply_embed(interaction, "Permission Denied", "এই action করার permission নেই.", ephemeral=True)
        if not tournament_options(interaction.guild_id):
            return await reply_embed(interaction, "No Tours", "এই server-এ কোনো tournament নেই.", ephemeral=True)
        await interaction.response.send_message(
            embed=make_embed("Slot List", "যে tournament-এর registered team ও player IGN দেখতে চাও, সেটি select করো."),
            view=SlotTourPicker(interaction.guild_id), ephemeral=True
        )

    @discord.ui.button(label="Set Payment", style=discord.ButtonStyle.secondary, custom_id="panel_payment")
    async def payment(self, interaction, button):
        if not is_manager(interaction.user):
            return await reply_embed(interaction, "Permission Denied", "এই action করার permission নেই.", ephemeral=True)
        await interaction.response.send_modal(PaymentModal())


async def send_panel(ctx):
    tours = tournament_options(ctx.guild.id)
    lines = []
    for index, tour in enumerate(tours, start=1):
        lines.append(
            f"**{index:02}.** **{tour['name']}** — "
            f"{(tour['tour_type'] or 'scrim').replace('_', ' ').title()} "
            f"(ID: `{tour['id']}`) — {tour['date_time'] or 'Time not set'}"
        )
    tour_text = "\n".join(lines) if lines else "No current tournaments."
    embed = make_embed(PANEL_TITLE, f"{tour_text}\n\n**Total Tours in this server: {len(tours)}**")
    if bot.user:
        embed.set_thumbnail(url=bot.user.display_avatar.url)
    await ctx.send(embed=embed, view=Panel())


# ============================================================
# COMMANDS / EVENTS
# ============================================================

@bot.command(name="setreg")
@commands.guild_only()
async def set_registration_channel(ctx, channel: discord.TextChannel = None):
    if not is_manager(ctx.author):
        return await reply_embed(ctx, "Permission Denied", "এই command ব্যবহার করার permission নেই.")
    if channel is None:
        return await reply_embed(ctx, "Registration Channel", "Registration channel এখন `paid-tour-reg` নামে auto-create হয়. চাইলে ব্যবহার: `!setreg #channel`")
    save_settings(ctx.guild.id, registration_channel_id=channel.id)
    await reply_embed(ctx, "Registration Channel Set", f"Registration channel: {channel.mention}")


@bot.command(name="ppt")
@commands.guild_only()
async def ppt_command(ctx):
    if not is_manager(ctx.author):
        return await reply_embed(ctx, "Permission Denied", "Admin অথবা Tournament Manager role লাগবে.")
    try:
        await ensure_mod_setup(ctx.guild)
        await ensure_registration_channel(ctx.guild)
    except discord.Forbidden:
        return await reply_embed(ctx, "Missing Permissions", "Bot-কে Manage Roles ও Manage Channels permission দাও. Bot role-টিও Scrim Mod role-এর উপরে রাখো.")
    except Exception as error:
        print("Setup error:", repr(error))
        return await reply_embed(ctx, "Setup Failed", "Setup করা যায়নি. CMD error পরীক্ষা করো.")
    await send_panel(ctx)


@bot.event
async def on_message(message):
    if message.author.bot:
        return
    if message.guild is None:
        await handle_screenshot(message)
        return
    if message.content.strip().lower() == "ppt":
        ctx = await bot.get_context(message)
        await ppt_command(ctx)
        return
    await bot.process_commands(message)


@bot.event
async def on_ready():
    global views_loaded
    init_db()
    if not views_loaded:
        bot.add_view(Panel())
        bot.add_view(RegistrationView())
        with db() as conn:
            pending = conn.execute("""
                SELECT id FROM registrations WHERE status='pending'
            """).fetchall()
        for row in pending:
            bot.add_view(ReviewView(row["id"]))
        views_loaded = True
    print(f"Logged in as {bot.user} — {PANEL_TITLE}")


if not TOKEN:
    raise RuntimeError(
        "DISCORD_BOT_TOKEN environment variable is missing. Set your bot token as an environment variable; do not paste it into the code."
    )

init_db()
bot.run(TOKEN)
