PRO ST Paid Tour Manager - Fix

1. Stop the currently running bot with Ctrl+C in its CMD window.
2. Make a backup copy of your current pro_st_paid_tour_manager.py.
3. Copy this pro_st_paid_tour_manager.py into C:\Users\cm\Documents\MY BOT and choose Replace.
4. Do NOT delete or replace probot.db.
5. Do NOT run the incomplete bot.py generator. It can overwrite the main bot file.
6. Start the bot from that folder with:
   python pro_st_paid_tour_manager.py

This version avoids opening a second modal directly from a modal submission. Instead it shows a Continue button, which opens the next modal from a button interaction.
