import os
import sqlite3
import discord
from discord.ext import commands
from discord import app_commands

TOKEN = os.getenv("DISCORD_BOT_TOKEN")
DB_FILE = "probot.db"
MANAGER_ROLE = "Tournament Manager"


# ---------- DATABASE ----------

def db():
    con = sqlite3.connect(DB_FILE, timeout=10)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with db() as con:
        con.execute("""
        CREATE TABLE IF NOT EXISTS tournaments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            mode TEXT DEFAULT 'Squad',
            date_time TEXT DEFAULT 'TBA',
            fee TEXT DEFAULT '0',
            total_slots INTEGER DEFAULT 12,
            guild_id INTEGER,
            role_id INTEGER,
            channel_id INTEGER
        )
        """)

        con.execute("""
        CREATE TABLE IF NOT EXISTS registrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tournament_id INTEGER NOT NULL,
            slot_number INTEGER,
            discord_user_id INTEGER NOT NULL,
            team_name TEXT NOT NULL,
            p1_ign TEXT NOT NULL,
            p1_uid TEXT DEFAULT '',
            p2_ign TEXT NOT NULL,
            p2_uid TEXT DEFAULT '',
            status TEXT DEFAULT 'Pending',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """)

        # পুরোনো Database থাকলে নতুন column যোগ করবে
        existing = {
            row["name"]
            for row in con.execute("PRAGMA table_info(tournaments)")
        }

        for name, definition in [
            ("guild_id", "INTEGER"),
            ("role_id", "INTEGER"),
            ("channel_id", "INTEGER"),
        ]:
            if name not in existing:
                con.execute(
                    f"ALTER TABLE tournaments ADD COLUMN {name} {definition}"
                )

        reg_columns = {
            row["name"]
            for row in con.execute("PRAGMA table_info(registrations)")
        }

        for name, definition in [
            ("status", "TEXT DEFAULT 'Pending'"),
            ("slot_number", "INTEGER"),
        ]:
            if name not in reg_columns:
                con.execute(
                    f"ALTER TABLE registrations ADD COLUMN {name} {definition}"
                )

        con.execute("""
        CREATE TABLE IF NOT EXISTS slots (
            tournament_id INTEGER NOT NULL,
            slot_number INTEGER NOT NULL,
            status TEXT DEFAULT 'Available',
            team_name TEXT,
            PRIMARY KEY (tournament_id, slot_number)
        )
        """)


# ---------- BOT ----------

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)


def is_manager(member):
    if not isinstance(member, discord.Member):
        return False

    return (
        member.guild_permissions.administrator
        or any(role.name == MANAGER_ROLE for role in member.roles)
    )


def get_tournament(tid):
    with db() as con:
        return con.execute(
            "SELECT * FROM tournaments WHERE id = ?", (tid,)
        ).fetchone()


def tournament_options():
    with db() as con:
        return con.execute(
            "SELECT id, name FROM tournaments ORDER BY id DESC"
        ).fetchall()


# ---------- CREATE TOURNAMENT ----------

class CreateTournamentModal(discord.ui.Modal, title="Create Tournament"):
    name = discord.ui.TextInput(
        label="Tournament Name", max_length=80
    )
    mode = discord.ui.TextInput(
    label="Tournament Type",
    placeholder="Scrim / Champion Rush / Custom Tournament",
    max_length=30
)
    date_time = discord.ui.TextInput(
        label="Date & Time", placeholder="Example: 20 Oct, 8 PM"
    )
    fee = discord.ui.TextInput(
        label="Entry Fee", placeholder="0"
    )
    total_slots = discord.ui.TextInput(
        label="Total Slots", placeholder="12"
    )

    async def on_submit(self, interaction: discord.Interaction):
        if not is_manager(interaction.user):
            return await interaction.response.send_message(
                "You don't have permission.", ephemeral=True
            )

        try:
            slots_count = int(str(self.total_slots.value))
            fee_value = float(str(self.fee.value))
            if not 1 <= slots_count <= 100 or fee_value < 0:
                raise ValueError
        except ValueError:
            return await interaction.response.send_message(
                "Slots 1–100 এবং Fee 0 বা তার বেশি দিতে হবে.",
                ephemeral=True
            )

        await interaction.response.defer(ephemeral=True)

        guild = interaction.guild
        if guild is None:
            return await interaction.followup.send(
                "এই কাজ Server-এর ভিতর থেকে করতে হবে.", ephemeral=True
            )

        try:
            # Tournament Role
            role = await guild.create_role(
                name=f"{self.name.value[:70]} Players",
                mentionable=False,
                reason="Pro Bot tournament setup"
            )

            # Private CG Channel: Admin এবং accepted Player দেখতে পারবে
            overwrites = {
                guild.default_role: discord.PermissionOverwrite(
                    view_channel=False,
                    send_messages=False,
                    create_public_threads=False,
                    create_private_threads=False,
                    send_messages_in_threads=False
                ),
                role: discord.PermissionOverwrite(
                    view_channel=True,
                    send_messages=False,
                    create_public_threads=False,
                    create_private_threads=False,
                    send_messages_in_threads=False
                )
            }

            for admin_role in guild.roles:
                if admin_role.permissions.administrator:
                    overwrites[admin_role] = discord.PermissionOverwrite(
                        view_channel=True,
                        send_messages=True,
                        create_public_threads=False,
                        create_private_threads=False
                    )

            channel = await guild.create_text_channel(
                name=f"cg-{self.name.value.lower().replace(' ', '-')[:70]}",
                overwrites=overwrites,
                reason="Private tournament CG channel"
            )

            with db() as con:
                cur = con.execute("""
                    INSERT INTO tournaments
                    (name, mode, date_time, fee, total_slots,
                     guild_id, role_id, channel_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    str(self.name.value),
                    str(self.mode.value),
                    str(self.date_time.value),
                    str(self.fee.value),
                    slots_count,
                    guild.id,
                    role.id,
                    channel.id
                ))
                tid = cur.lastrowid

                for slot in range(1, slots_count + 1):
                    con.execute("""
                        INSERT OR IGNORE INTO slots
                        (tournament_id, slot_number, status)
                        VALUES (?, ?, 'Available')
                    """, (tid, slot))

            await interaction.followup.send(
                f"✅ Tournament Created!\n"
                f"**ID:** {tid}\n"
                f"**Name:** {self.name.value}\n"
                f"**CG Channel:** {channel.mention}\n"
                f"**Role:** {role.mention}",
                ephemeral=True
            )

        except discord.Forbidden:
            await interaction.followup.send(
                "❌ Bot-এর Manage Roles / Manage Channels Permission নেই, "
                "অথবা Bot-এর Role প্রয়োজনীয় Role-এর উপরে নেই.",
                ephemeral=True
            )
        except Exception as error:
            await interaction.followup.send(
                f"❌ Error: {type(error).__name__}: {error}",
                ephemeral=True
            )


# ---------- PUBLIC TOURNAMENT POST ----------

class TournamentSelect(discord.ui.Select):
    def __init__(self, action):
        self.action = action
        rows = tournament_options()

        options = [
            discord.SelectOption(
                label=row["name"][:100],
                value=str(row["id"]),
                description=f"Tournament ID: {row['id']}"
            )
            for row in rows[:25]
        ]

        if not options:
            options = [
                discord.SelectOption(
                    label="No tournaments yet", value="none"
                )
            ]

        super().__init__(
            placeholder="Select a Tournament",
            min_values=1,
            max_values=1,
            options=options
        )

    async def callback(self, interaction: discord.Interaction):
        if not is_manager(interaction.user):
            return await interaction.response.send_message(
                "Admin/Manager only.", ephemeral=True
            )

        if self.values[0] == "none":
            return await interaction.response.send_message(
                "আগে Tournament তৈরি করো.", ephemeral=True
            )

        tid = int(self.values[0])

        if self.action == "publish":
            row = get_tournament(tid)
            if not row:
                return await interaction.response.send_message(
                    "Tournament পাওয়া যায়নি.", ephemeral=True
                )

            embed = discord.Embed(
                title=f"🏆 {row['name']}",
                description=(
                    f"**Mode:** {row['mode']}\n"
                    f"**Date:** {row['date_time']}\n"
                    f"**Entry Fee:** {row['fee']}\n"
                    f"**Total Slots:** {row['total_slots']}\n\n"
                    "Register below to reserve your team slot."
                ),
                color=discord.Color.gold()
            )
            embed.set_footer(text=f"Pro Bot • Tournament ID: {tid}")

            await interaction.channel.send(
                embed=embed,
                view=PublicRegistrationView(tid)
            )
            return await interaction.response.send_message(
                "✅ Tournament post published.", ephemeral=True
            )

        if self.action == "review":
            return await interaction.response.send_message(
                f"**{get_tournament(tid)['name']}** registrations:",
                view=ReviewPanel(tid),
                ephemeral=True
            )

        if self.action == "slots":
            with db() as con:
                rows = con.execute("""
                    SELECT slot_number, status, team_name
                    FROM slots WHERE tournament_id = ?
                    ORDER BY slot_number
                """, (tid,)).fetchall()

            text = "\n".join(
                f"Slot {r['slot_number']}: {r['status']}"
                + (f" — {r['team_name']}" if r["team_name"] else "")
                for r in rows
            )
            return await interaction.response.send_message(
                f"**Tournament ID: {tid}**\n{text or 'No slots'}",
                ephemeral=True
            )


class TournamentPicker(discord.ui.View):
    def __init__(self, action):
        super().__init__(timeout=180)
        self.add_item(TournamentSelect(action))


# ---------- REGISTRATION ----------

class RegistrationModal(discord.ui.Modal, title="Team Registration"):
    team = discord.ui.TextInput(label="Team Name", max_length=50)
    p1 = discord.ui.TextInput(label="Player 1 IGN", max_length=40)
    p2 = discord.ui.TextInput(label="Player 2 IGN", max_length=40)

    def __init__(self, tid):
        super().__init__()
        self.tid = tid

    async def on_submit(self, interaction: discord.Interaction):
        row = get_tournament(self.tid)
        if not row:
            return await interaction.response.send_message(
                "Tournament পাওয়া যায়নি.", ephemeral=True
            )

        with db() as con:
            existing = con.execute("""
                SELECT id FROM registrations
                WHERE tournament_id = ? AND discord_user_id = ?
                  AND status != 'Rejected'
            """, (self.tid, interaction.user.id)).fetchone()

            if existing:
                return await interaction.response.send_message(
                    "তুমি এই Tournament-এ ইতিমধ্যে Registration করেছ.",
                    ephemeral=True
                )

            # প্রথম Available Slot — বুকিংয়ের ক্রম অনুযায়ী
            slot = con.execute("""
                SELECT slot_number FROM slots
                WHERE tournament_id = ? AND status = 'Available'
                ORDER BY slot_number LIMIT 1
            """, (self.tid,)).fetchone()

            if not slot:
                return await interaction.response.send_message(
                    "দুঃখিত, সব Slot বুক হয়ে গেছে.", ephemeral=True
                )

            slot_number = slot["slot_number"]

            con.execute("""
                UPDATE slots
                SET status = 'Pending', team_name = ?
                WHERE tournament_id = ? AND slot_number = ?
                  AND status = 'Available'
            """, (str(self.team.value), self.tid, slot_number))

            con.execute("""
                INSERT INTO registrations
                (tournament_id, slot_number, discord_user_id,
                 team_name, p1_ign, p2_ign, status)
                VALUES (?, ?, ?, ?, ?, ?, 'Pending')
            """, (
                self.tid, slot_number, interaction.user.id,
                str(self.team.value), str(self.p1.value),
                str(self.p2.value)
            ))

        await interaction.response.send_message(
            f"📝 Registration submitted!\n"
            f"**Team:** {self.team.value}\n"
            f"**Slot:** {slot_number}\n"
            "Admin approval is pending.",
            ephemeral=True
        )


class RegisterButton(discord.ui.Button):
    def __init__(self, tid):
        super().__init__(
            label="Register Now",
            style=discord.ButtonStyle.success,
            custom_id=f"probot:register:{tid}"
        )
        self.tid = tid

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.send_modal(RegistrationModal(self.tid))


class PublicRegistrationView(discord.ui.View):
    def __init__(self, tid):
        super().__init__(timeout=None)
        self.add_item(RegisterButton(tid))


# ---------- ADMIN ACCEPT / REJECT ----------

class RegistrationDecision(discord.ui.View):
    def __init__(self, registration_id):
        super().__init__(timeout=180)
        self.registration_id = registration_id

    async def decide(self, interaction, accepted):
        if not is_manager(interaction.user):
            return await interaction.response.send_message(
                "Admin/Manager only.", ephemeral=True
            )

        with db() as con:
            reg = con.execute("""
                SELECT * FROM registrations WHERE id = ?
            """, (self.registration_id,)).fetchone()

            if not reg or reg["status"] != "Pending":
                return await interaction.response.send_message(
                    "Registration আর Pending নেই.", ephemeral=True
                )

            tour = con.execute("""
                SELECT * FROM tournaments WHERE id = ?
            """, (reg["tournament_id"],)).fetchone()

            if accepted:
                guild = interaction.guild
                if not guild or not tour["role_id"]:
                    return await interaction.response.send_message(
                        "Tournament Role পাওয়া যায়নি.", ephemeral=True
                    )

                member = guild.get_member(reg["discord_user_id"])
                role = guild.get_role(tour["role_id"])

                if member is None:
                    try:
                        member = await guild.fetch_member(
                            reg["discord_user_id"]
                        )
                    except discord.NotFound:
                        return await interaction.response.send_message(
                            "Player এই Server-এ নেই; Role দেওয়া যায়নি.",
                            ephemeral=True
                        )

                if role:
                    await member.add_roles(
                        role, reason="Tournament registration accepted"
                    )

                con.execute("""
                    UPDATE registrations SET status = 'Accepted'
                    WHERE id = ?
                """, (self.registration_id,))
                con.execute("""
                    UPDATE slots SET status = 'Booked'
                    WHERE tournament_id = ? AND slot_number = ?
                """, (reg["tournament_id"], reg["slot_number"]))

                result = f"✅ Accepted: {reg['team_name']} — Slot {reg['slot_number']}"
            else:
                con.execute("""
                    UPDATE registrations SET status = 'Rejected'
                    WHERE id = ?
                """, (self.registration_id,))
                con.execute("""
                    UPDATE slots SET status = 'Available', team_name = NULL
                    WHERE tournament_id = ? AND slot_number = ?
                """, (reg["tournament_id"], reg["slot_number"]))

                result = f"❌ Rejected: {reg['team_name']}"

        await interaction.response.edit_message(
            content=result, view=None
        )

    @discord.ui.button(label="Accept", style=discord.ButtonStyle.success)
    async def accept(self, interaction, button):
        await self.decide(interaction, True)

    @discord.ui.button(label="Reject", style=discord.ButtonStyle.danger)
    async def reject(self, interaction, button):
        await self.decide(interaction, False)


class PendingRegistrationSelect(discord.ui.Select):
    def __init__(self, tid):
        self.tid = tid

        with db() as con:
            rows = con.execute("""
                SELECT id, team_name, slot_number
                FROM registrations
                WHERE tournament_id = ? AND status = 'Pending'
                ORDER BY id
            """, (tid,)).fetchall()

        options = [
            discord.SelectOption(
                label=f"Slot {r['slot_number']} — {r['team_name']}"[:100],
                value=str(r["id"])
            )
            for r in rows[:25]
        ]

        if not options:
            options = [
                discord.SelectOption(
                    label="No pending registrations", value="none"
                )
            ]

        super().__init__(
            placeholder="Choose a pending registration",
            min_values=1,
            max_values=1,
            options=options
        )

    async def callback(self, interaction):
        if not is_manager(interaction.user):
            return await interaction.response.send_message(
                "Admin/Manager only.", ephemeral=True
            )

        if self.values[0] == "none":
            return await interaction.response.send_message(
                "কোনো Pending Registration নেই.", ephemeral=True
            )

        rid = int(self.values[0])

        with db() as con:
            reg = con.execute(
                "SELECT * FROM registrations WHERE id = ?", (rid,)
            ).fetchone()

        await interaction.response.send_message(
            f"**Team:** {reg['team_name']}\n"
            f"**Player 1:** {reg['p1_ign']}\n"
            f"**Player 2:** {reg['p2_ign']}\n"
            f"**Slot:** {reg['slot_number']}\n"
            f"**Player Discord ID:** {reg['discord_user_id']}",
            view=RegistrationDecision(rid),
            ephemeral=True
        )


class ReviewPanel(discord.ui.View):
    def __init__(self, tid):
        super().__init__(timeout=180)
        self.add_item(PendingRegistrationSelect(tid))


# ---------- ADMIN PANEL ----------

class Panel(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    async def interaction_check(self, interaction):
        if not is_manager(interaction.user):
            await interaction.response.send_message(
                "❌ শুধু Admin অথবা Tournament Manager ব্যবহার করতে পারবে.",
                ephemeral=True
            )
            return False
        return True

    @discord.ui.button(
        label="Create Tournament",
        style=discord.ButtonStyle.primary,
        custom_id="probot:create"
    )
    async def create(self, interaction, button):
        await interaction.response.send_modal(CreateTournamentModal())

    @discord.ui.button(
        label="Publish Tournament",
        style=discord.ButtonStyle.success,
        custom_id="probot:publish"
    )
    async def publish(self, interaction, button):
        await interaction.response.send_message(
            "কোন Tournament Publish করবে?",
            view=TournamentPicker("publish"),
            ephemeral=True
        )

    @discord.ui.button(
        label="Review Registrations",
        style=discord.ButtonStyle.primary,
        custom_id="probot:review"
    )
    async def review(self, interaction, button):
        await interaction.response.send_message(
            "কোন Tournament-এর Registration Review করবে?",
            view=TournamentPicker("review"),
            ephemeral=True
        )

    @discord.ui.button(
        label="Manage Slots",
        style=discord.ButtonStyle.secondary,
        custom_id="probot:slots"
    )
    async def slots(self, interaction, button):
        await interaction.response.send_message(
            "কোন Tournament-এর Slots দেখবে?",
            view=TournamentPicker("slots"),
            ephemeral=True
        )


@bot.event
async def on_ready():
    init_db()
    bot.add_view(Panel())

    # Restart-এর পরও পুরোনো Public Register button সচল রাখা
    with db() as con:
        rows = con.execute(
            "SELECT id FROM tournaments"
        ).fetchall()

    for row in rows:
        bot.add_view(PublicRegistrationView(row["id"]))

    print(f"Bot is online: {bot.user}")


@bot.event
async def on_message(message):
    if message.author.bot:
        return

    if message.content.strip().lower() == "ppt":
        if is_manager(message.author):
            await message.channel.send(
                "🏆 **PRO BOT — Tournament Control Panel**",
                view=Panel()
            )

    await bot.process_commands(message)


if not TOKEN:
    raise RuntimeError(
        "DISCORD_BOT_TOKEN পাওয়া যায়নি। CMD-তে Token Environment Variable সেট করো."
    )

init_db()
bot.run(TOKEN)